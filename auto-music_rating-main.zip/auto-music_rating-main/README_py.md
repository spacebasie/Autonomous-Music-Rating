# Autonomous Music Practice Rating - Python Version
This is our 351 Autonomus Music Practice Rating Project!
By:
Stefanos A Frilingos
Blake A Hall
Wentao Xu
Xiangdong Wei
Haoliang Cheng

This read-me as indicated by the headline refers to the python program, "note_rate.py" which includes functions for the correlation matrix, pitch and tempo analysis. The demo to be ran is the file "demo_rate.py". This demo compares two short sample guitar pieces that we recorded ourselves. More information on the analysis of the graphs shown in this demo can be found on our website at: https://midirate351.wixsite.com/eecs351f22

<!-- Instructions for how to proceed with the demo -->

# Step 1 - Installing the librosa library
All files python files are included in the zip submission. For simplicity, the two pieces named "guitart1.wav" and "guitart2.wav" are already passed in through the loading functions, so you will not need to input anything to run the program. 

Before running the demo, you will need to install the 'librosa' python library, which is our primary helper package. This can quickly be done from your terminal either with 
pip: "pip install librosa" 

or with anaconda: "conda install -c conda-forge librosa"

After installing librosa on your computer, and you have a running version of python (Python 3 is preferred), you only need to run the program

# Step 2 - Running the program
Simply run the command "python3 demo_rate.py" on your terminal where the files have been saved, and all plots and terminal output should be displayed.
Make sure that all required files are in the same directory, including: ('note_rate.py', 'demo_rate.py', 'guitart1.wav', 'guitart2.wav', 'README_py.md')

# Troubleshooting
If there any issues are encountered when installing the packages or running the program, please contact us directly at:
e-mail: midirate351@gmail.com
